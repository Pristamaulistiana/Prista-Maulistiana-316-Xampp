function showSection(sectionId) {
  document.querySelectorAll('.content-section').forEach(section => {
    section.style.display = 'none';
  });
  document.getElementById(sectionId).style.display = 'block';
}

window.onload = function() {
  fetch('inventory.php')
    .then(response => response.json())
    .then(data => {
      const tbody = document.querySelector('#inventoryTable tbody');
      data.forEach(item => {
        const row = `<tr><td>${item.id}</td><td>${item.nama}</td><td>${item.jumlah}</td><td>${item.lokasi}</td><td>${item.kondisi}</td></tr>`;
        tbody.innerHTML += row;
      });
    });
};
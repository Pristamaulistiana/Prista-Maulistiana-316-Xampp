CREATE DATABASE IF NOT EXISTS inventory_kantor;
USE inventory_kantor;

CREATE TABLE inventaris (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100),
  jumlah INT,
  lokasi VARCHAR(100),
  kondisi VARCHAR(50)
);

INSERT INTO inventaris (nama, jumlah, lokasi, kondisi) VALUES
('Meja Kerja', 10, 'Ruang Utama', 'Baik'),
('Kursi Kantor', 15, 'Ruang Utama', 'Baik'),
('Lemari Arsip', 4, 'Gudang', 'Cukup'),
('Komputer', 7, 'Ruang IT', 'Baik'),
('Printer', 3, 'Ruang IT', 'Rusak Ringan'),
('Proyektor', 2, 'Ruang Meeting', 'Baik'),
('Whiteboard', 2, 'Ruang Meeting', 'Baik'),
('AC Split', 5, 'Seluruh Ruangan', 'Baik'),
('Kabel LAN', 20, 'Gudang', 'Baik'),
('Switch Hub', 2, 'Ruang IT', 'Cukup'),
('Meja Rapat', 1, 'Ruang Meeting', 'Baik'),
('Kursi Lipat', 10, 'Gudang', 'Cukup'),
('Speaker', 2, 'Ruang Multimedia', 'Baik'),
('Mic Wireless', 1, 'Ruang Multimedia', 'Baik'),
('Kamera CCTV', 6, 'Seluruh Ruangan', 'Baik'),
('Kipas Angin', 4, 'Gudang', 'Baik'),
('Laptop', 3, 'Ruang Direktur', 'Baik'),
('Scanner', 1, 'Ruang Arsip', 'Rusak Ringan'),
('Meja Resepsionis', 1, 'Lobby', 'Baik'),
('Rak Buku', 3, 'Perpustakaan', 'Baik');